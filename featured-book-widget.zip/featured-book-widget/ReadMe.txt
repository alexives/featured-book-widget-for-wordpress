Plugin Name: Featured Book Widget
Plugin URI: https://bitbucket.org/aives/featured-book-widget-for-wordpress
Description: A widget for featuring books in a widget. Takes an isbn and pulls the cover and other info from google.
Author: Alex Ives
Version: 1
Author URI: http://alexiv.es

Installation: Download a zipped copy of the plugin and upload 
using the wordpress plugin installer. Then go to Appearance-> 
Widgets and add to a sidebar. Put the isbn of the book you want 
into the isbn field, the title for the widget into the title 
field, and if you want it to link to a page in your site, put 
in the link field. 

License: CC Attribution-ShareAlke Version 3
License URI: http://creativecommons.org/licenses/by-sa/3.0/